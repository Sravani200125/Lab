import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DoctorService } from '../doctor.service';
import { FeedbackService } from '../feedback.service';
import { PatientService } from '../patient.service';

@Component({
  selector: 'app-givefeedback',
  templateUrl: './givefeedback.component.html',
  styleUrls: ['./givefeedback.component.css']
})
export class GivefeedbackComponent implements OnInit {
  pats:any[];
  docs:any[];
  appForm: FormGroup;

  constructor(private fb: FormBuilder,private pService:PatientService,private dService:DoctorService,
    private fService:FeedbackService) { }

  ngOnInit(): void {
    this.appForm = this.fb.group({
      
      doctor: new FormGroup({
        doctorId: new FormControl('',Validators.required)
      }),
      patient: new FormGroup({
        patientId: new FormControl('',Validators.required)
      }),
      rating: ['', Validators.required],
      feedback: ['', Validators.required]
    }),

    this.pService.getAllPat().subscribe((data)=>{
      this.pats=data;
    }),
    this.dService.getAllDoc().subscribe((data)=>{
      this.docs=data;
    })
  }

  addfeed(){
    this.fService.addFeedback(this.appForm.value).subscribe((data)=>{
      alert("Thanks!!Your feedback was submitted");
    })

  }

}
