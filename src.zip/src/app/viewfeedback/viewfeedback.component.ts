import { Component, OnInit } from '@angular/core';
import { FeedbackService } from '../feedback.service';

@Component({
  selector: 'app-viewfeedback',
  templateUrl: './viewfeedback.component.html',
  styleUrls: ['./viewfeedback.component.css']
})
export class ViewfeedbackComponent implements OnInit {
  feed:any[];
  constructor(private fService:FeedbackService) { }

  ngOnInit(): void {
    this.fService.getAllFeedbacks().subscribe((data)=>{
      this.feed=data;
    })

  }

}
