import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CreateComponent } from './employee/create/create.component';
import { AllEmployeeComponent } from './employee/all-employee/all-employee.component';
import { UpdateComponent } from './employee/update/update.component';
import { AuthGuard } from './auth.guard';
import { HttpClientModule } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import {MatToolbarModule} from '@angular/material/toolbar';
import { SearchByIDPipe} from './search-by-id.pipe';
import { SearchByDatePipe } from './search-by-date.pipe';
import { SearchByStatusPipe } from './search-by-status.pipe';
import { SearchByValuePipe } from './search-by-value.pipe';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { AdminApproveComponent } from './admin/admin-approve/admin-approve.component' ;
import { HomeComponent } from './home/home.component';
import { SearchByDoctorPipe } from './search-by-doctor.pipe';
import { SearchByPatientPipe } from './search-by-patient.pipe';
import { CreatePatientComponent } from './patient/create-patient/create-patient.component';
import {MatSelectModule} from '@angular/material/select'
import {CommonModule} from '@angular/common'
import { Patient } from './patient/patient';
import { PatientComponent } from './patient/patient.component';
import { FindallComponent } from './patient/findall/findall.component';
import { UpdatePatientComponent } from './patient/update-patient/update-patient.component';
import { UpdatedoctorComponent } from './doctorcrud/updatedoctor/updatedoctor.component';
import { AlldoctorComponent } from './doctorcrud/alldoctor/alldoctor.component';
import { CreatedoctorComponent } from './doctorcrud/createdoctor/createdoctor.component';
import { FilterHnamePipe } from './filter-hname.pipe';
import { FilterchargesPipe } from './filtercharges.pipe';
import { FilterlocationPipe } from './filterlocation.pipe';
import { FilteridPipe } from './filterid.pipe';
import { FilternamePipe } from './filtername.pipe';
import { FilternumberPipe } from './filternumber.pipe';
import { SpecialityPipe } from './filterspeciality.pipe';
import { LoginComponent } from './login/login.component';
import { DoctorcrudComponent } from './doctorcrud/doctorcrud.component';
import { GivefeedbackComponent } from './givefeedback/givefeedback.component';
import { ViewfeedbackComponent } from './viewfeedback/viewfeedback.component';


@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    CreateComponent,
    PatientComponent,
    AllEmployeeComponent,
    UpdateComponent,
    SearchByIDPipe,
    SearchByDatePipe,
    SearchByStatusPipe,
    SearchByValuePipe,
    FilterHnamePipe,
    FilterchargesPipe,
    FilterlocationPipe,
    FilteridPipe,
    FilternamePipe,
    FilternumberPipe,
    SpecialityPipe,
    UserComponent,
    AdminComponent,
    AdminApproveComponent,
    HomeComponent,
    SearchByDoctorPipe,
    SearchByPatientPipe,
    CreatePatientComponent,
    FindallComponent,
    UpdatePatientComponent,
    UpdatedoctorComponent,
    AlldoctorComponent,
    CreatedoctorComponent,
    UpdatedoctorComponent,
    LoginComponent,
    DoctorcrudComponent,
    GivefeedbackComponent,
    ViewfeedbackComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    FlexLayoutModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    MatSelectModule,
    MatToolbarModule,
    CommonModule
  ],
  exports :[
    MatInputModule
  ],
  providers: [
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
