import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
  private url="http://localhost:8085//mydoctorapp-feedback";
  httpOptions={
    headers:new HttpHeaders({
         'Content-Type':'application/json'
    })
  }

  constructor(private httpClient:HttpClient) { }

  getAllFeedbacks():Observable<any> {
    return this.httpClient.get<any>(this.url+'/allfeedback')
    .pipe(
      catchError(this.handleError)
    )

  }


  addFeedback(feed: any):Observable<any> {
    return this.httpClient.post<any>(this.url+'/addfeedback',JSON.stringify(feed),this.httpOptions)
    .pipe(
      catchError(this.handleError)
    )


  }


  handleError(eResponse: HttpErrorResponse) {
    if (eResponse.error instanceof ErrorEvent) {
      console.log("Client Side Error =" + eResponse.error.message);
      console.log("Status Code=" + eResponse.status);
    }
    else {
      console.log("Server Side Error =" + eResponse.error.message);
      console.log("Status Code=" + eResponse.status);
    }
    return throwError(eResponse.error.message);
  }

}


