import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { PatientService } from './patient.service';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})
export class PatientComponent implements OnInit {

  constructor(private fb:FormBuilder ,private pService:PatientService, private adminService:AdminService, private router:Router) { }
  message:string;
  loginForm: FormGroup;

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      uname: ['', [Validators.required,Validators.email]],
      password: ['', Validators.required],
    })
  }

  signUp(){
    this.router.navigate(['/addUser']);
  }

  login(){
    if(this.pService.validateLoginCredentials(this.loginForm.value)){
      this.pService.setLoginStatus(true);
      this.adminService.setAdminStatus(false);
      this.router.navigate(['/employee']);

    }
    else{
      this.message = "Invalid Login details check ID and Password";
      this.router.navigate(['/login']);
    }
  }

}
