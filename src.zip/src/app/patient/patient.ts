export class Patient {
    public patientId : number;
    public patientName : string;
	public mobileNo : number;
	public email : string;
	public bloodGroup : string;
	public gender : string;
	public age : number;
	public address : string;
}