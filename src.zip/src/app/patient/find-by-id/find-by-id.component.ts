import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Patient } from '../patient';
import { PatientService } from '../patient.service';

@Component({
  selector: 'app-find-by-id',
  templateUrl: './find-by-id.component.html',
  styleUrls: ['./find-by-id.component.css']
})
export class FindByIdComponent implements OnInit {
  patientForm: FormGroup;
  pat: Patient;
  constructor(private fb: FormBuilder, private actRouter: ActivatedRoute, private pService: PatientService, private router: Router) { }

  ngOnInit(): void {
    this.patientForm = this.fb.group({
      patientId: ['', Validators.required]
    })
  }
  searchPatient(patientId: number) {
    this.pat = new Patient();
    this.pService.getPatientById(patientId).subscribe(data => {
      this.pat = data;
      console.log(data);
    })
  }
}
