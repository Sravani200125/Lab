import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { Patient } from './patient';
import { catchError } from 'rxjs/operators'
import { UserLogin } from '../Userlogin';



@Injectable({
  providedIn: 'root'
})
export class PatientService {
  private url = "http://localhost:8085";
  patientData:any=[];
  userData:UserLogin[];
  private isLoginStatus:boolean=false;
  
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  constructor(private httpClient: HttpClient) { 
    this.getAllUsers().subscribe((data:any[])=>{
      this.userData = data;
    })
  }


  getLoginStatus():any {
    return this.isLoginStatus;
    }
  
    setLoginStatus(status:boolean){
      this.isLoginStatus = status;
    }

  getPatientById(id: any): Observable<Patient> {
    return this.httpClient.get<Patient>(this.url + '/mydoctorapp-patient/getpatientbyid/' + id).
      pipe(
        catchError(this.handleError)
      );
  }
  addPatient(pat: any): Observable<any> {
    return this.httpClient.post<Patient>(this.url + '/mydoctorapp-patient/createpatient/', JSON.stringify(pat), this.httpOptions)
      .pipe(
        catchError(this.handleError)
      )
  }
  updatePatient(pat: any): Observable<any> {
    return this.httpClient.put<Patient>(this.url + '/mydoctorapp-patient/updatepatient', JSON.stringify(pat), this.httpOptions)
      .pipe(
        catchError(this.handleError)
      )
  }
  getAllPatient(): Observable<Patient[]> {
    return this.httpClient.get<Patient[]>(this.url + '/mydoctorapp-patient/patient/all').
      pipe(
        catchError(this.handleError)
      );
  }
  
  getAllUsers(): Observable<UserLogin[]> {
    return this.httpClient.get<UserLogin[]>(this.url + '/mydoctorapp-user/user/all').
      pipe(
        catchError(this.handleError)
      );
  }


  validateLoginCredentials(data:any):boolean{
    for(let p of this.userData){
      if(p.userName===data.uname && p.password===data.password){
        return true;
      }
    }
    return false;
  }

  deletePatient(pat: number): Observable<Patient[]> {
    return this.httpClient.delete<Patient[]>(this.url + '/mydoctorapp-patient/deletepatient/' + pat).
      pipe(
        catchError(this.handleError)
      );
  }

  handleError(eResponse: HttpErrorResponse) {
    if (eResponse.error instanceof ErrorEvent) {
      console.log("Client Side Error =" + eResponse.error.message);
      console.log("Status Code=" + eResponse.status);
    }
    else {
      console.log("Server Side Error =" + eResponse.error.message);
      console.log("Status Code=" + eResponse.status);
    }
    return throwError(eResponse.error.message);
  }
}
