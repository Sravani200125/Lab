import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Patient } from '../patient';
import { PatientService } from '../patient.service';

@Component({
  selector: 'app-update-patient',
  templateUrl: './update-patient.component.html',
  styleUrls: ['./update-patient.component.css']
})
export class UpdatePatientComponent implements OnInit {
  patientForm: FormGroup;
  patientId : number;
  pat : Patient;
  bloodgrp: string[] = ['A+','A-','B+','B-','O+','O-','AB+','AB-'];
  gendrType: string[] = ['Male','Female']

  constructor(private fb: FormBuilder, private actRouter: ActivatedRoute, private pService: PatientService, private router: Router) {

    this.pat = new Patient();
    this.patientId = this.actRouter.snapshot.params['patientId'];
    this.pService.getPatientById(this.patientId).subscribe(res => {
      this.pat = res;
    })


   }

  ngOnInit(): void {

  }
  updatePatient() {
    this.pService.updatePatient(this.pat).subscribe(res => {
      this.router.navigate(['/patient/allPatient'])
    })
  }

}

