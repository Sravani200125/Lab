import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PatientService } from '../patient.service';

@Component({
  selector: 'app-create-patient',
  templateUrl: './create-patient.component.html',
  styleUrls: ['./create-patient.component.css']
})
export class CreatePatientComponent implements OnInit {
  patientForm: FormGroup;
  errorMessage: string;
  constructor(private fb: FormBuilder, private pService: PatientService, private router: Router) { }

  ngOnInit(): void {
    this.patientForm = this.fb.group({
      patientId: ['', Validators.required],
      patientName: ['', [Validators.required, Validators.pattern("^[a-zA-Z\\s]*$")]],
      mobileNo: ['', [Validators.required,Validators.pattern("[6-9][0-9 ]{9}")]],
      email: ['', [Validators.required, Validators.email]],
      bloodGroup: ['', [Validators.required, Validators.pattern("^(A|B|AB|O)[-+]$")]],
      gender: ['', [Validators.required, Validators.pattern("^(Male|Female)$")]],
      age: ['', [Validators.required,Validators.pattern("^[1-9][0-9]?$")]],
      address: ['', Validators.required]
    })
  }

  get mob(){
    return this.patientForm.get('mobileNo');
  }
  get gender(){
    return this.patientForm.get('gender');
  }

  get pass(){
    return this.patientForm.get('password');
  }
  get pname() {
    return this.patientForm.get('patientName');
  }

  get bgroup(){
    return this.patientForm.get('bloodGroup');
  }

  get age(){
    return this.patientForm.get('age');
  }

  get email(){
    return this.patientForm.get('email');
  }
  regPatient() {
    this.pService.addPatient(this.patientForm.value).subscribe(res => {
      this.router.navigate(['/patient/allPatient'])
    }, error => {

      this.errorMessage = error;
      this.router.navigate(['/patient/addPatient']);
    }
    )

  }
}