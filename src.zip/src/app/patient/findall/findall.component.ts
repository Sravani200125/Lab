import { Component, OnInit } from '@angular/core';
import { Patient } from '../patient';
import { PatientService } from '../patient.service';

@Component({
  selector: 'app-findall',
  templateUrl: './findall.component.html',
  styleUrls: ['./findall.component.css']
})
export class FindallComponent implements OnInit {
  pid: string;
  name: string;
  mobile: string;
  email: string;
  bloodGroup: string;
  gender: string ;
  age: string;
  address:string;
  patients: Patient[];
  myArray: Patient[];
  constructor(private pService: PatientService) { }

  ngOnInit(): void {
    this.pService.getAllPatient().subscribe((data : any) => {
      this.patients = data;
      this.myArray = data;
    })
  }
  
  removePatient(patientId: number) {
    this.pService.deletePatient(patientId).subscribe((data: Patient[]) => {
      this.patients = data;
    })
  }

  searchById() {
    this.myArray = this.patients.filter(data => data.patientId.toString().match(this.pid));
  }
  searchByName() {
    this.myArray = this.patients.filter(data => data.patientName.match(this.name));
  }
  searchByMobile() {
    this.myArray = this.patients.filter(data => data.mobileNo.toString().match(this.mobile));
  }
  searchByEmail() {
    this.myArray = this.patients.filter(data => data.email.match(this.email));
  }
  searchByBlood() {
    this.myArray = this.patients.filter(data => data.bloodGroup.match(this.bloodGroup));
  }
  searchByGender() {
    this.myArray = this.patients.filter(data => data.gender.match(this.gender));
  }
  searchByAge() {
    this.myArray = this.patients.filter(data => data.age.toString().match(this.age));
  }
  searchByAddress() {
    this.myArray = this.patients.filter(data => data.address.match(this.address));
  }

}
