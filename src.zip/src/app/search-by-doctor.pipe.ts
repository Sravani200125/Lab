import { Pipe, PipeTransform } from '@angular/core';
import { Employee } from './employee/employee';

@Pipe({
  name: 'searchByDoctor'
})
export class SearchByDoctorPipe implements PipeTransform {

  transform(employees: Employee[], searchFilter: string): Employee[] {
    if (!employees || !searchFilter) {
      return employees;
    }
    else {
      return employees.filter(emp => emp.doctor.doctorId.toString().toLocaleLowerCase().includes(searchFilter.toLocaleLowerCase()));
    }
  }
}