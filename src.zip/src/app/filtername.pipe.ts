import { Pipe, PipeTransform } from '@angular/core';
import { Doctor } from './doctorcrud/Doctor';


@Pipe({
  name: 'filtername'
})
export class FilternamePipe implements PipeTransform {

  transform(Doctors: Doctor[], searchFilter: string): Doctor[] {
    if (!Doctors || !searchFilter) {
      return Doctors;
    }
    else {
      return Doctors.filter(doctor => doctor.doctorName.toString().toLocaleLowerCase().includes(searchFilter.toLocaleLowerCase()));
    }
  }
}
