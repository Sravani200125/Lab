export class Userdata{
    
    public userId:number;
    public email:string;
    public passowrd:string;
    public role:string;

}