import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  userForm:FormGroup;
  errormsg:string;

  constructor(private fb:FormBuilder,private lService:LoginService,private router:Router) {
    
   }

  ngOnInit(): void {
    this.userForm=this.fb.group({
      userId:['', Validators.required],
      email:['', [Validators.required,Validators.email]],
      password: [
        '',
        [
          Validators.required,
          Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')
         ]
      ],
      role:['', Validators.required],
    })
  }

  regUser(){
    this.lService.addUser(this.userForm.value).subscribe(res =>{
      this.router.navigate(['/doctor'])
    })
  }

}
