import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { UserLogin } from './Userlogin';


@Injectable({
  providedIn: 'root'
})
export class DocloginService {
  userList: UserLogin[];

  private url="http://localhost:8085//mydoctorapp-user";
  httpOptions={
    headers:new HttpHeaders({
         'Content-Type':'application/json'
    })
  }
  
  docId:number;
  
  private isDoctorStatus:boolean=false;

  getDoctorStatus(){
    return this.isDoctorStatus;
  }

  setDoctorStatus(status:boolean){
    this.isDoctorStatus=status;
  }

  
  
  constructor(private httpClient:HttpClient) { 
    this.getAllUsers().subscribe((data)=>{
      this.userList=data;
    })
  }
  

  getAllUsers():Observable<UserLogin[]> {
    return this.httpClient.get<UserLogin[]>(this.url+'/user/all')
    .pipe(
      catchError(this.handleError)
    )
  }

  
  validate(data:any):boolean{
    for(let u of this.userList){
      if(u.userName===data.uname && u.password===data.password){
        return true;
      }
    }
    return false;
  }

  handleError(eResponse: HttpErrorResponse) {
    if (eResponse.error instanceof ErrorEvent) {
      console.log("Client Side Error =" + eResponse.error.message);
      console.log("Status Code=" + eResponse.status);
    }
    else {
      console.log("Server Side Error =" + eResponse.error.message);
      console.log("Status Code=" + eResponse.status);
    }
    return throwError(eResponse.error.message);
  }
}
