import { Pipe, PipeTransform } from '@angular/core';
import { Employee } from './employee/employee';

@Pipe({
  name: 'searchByPatient'
})
export class SearchByPatientPipe implements PipeTransform {

  transform(employees: Employee[], searchFilter: string): Employee[] {
    if (!employees || !searchFilter) {
      return employees;
    }
    else {
      return employees.filter(emp => emp.patient.patientId.toString().toLocaleLowerCase().includes(searchFilter.toLocaleLowerCase()));
    }
  }
}