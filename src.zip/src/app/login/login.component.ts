import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  message:string;
  loginForm: FormGroup;

  constructor(private fb: FormBuilder,private router:Router, private lService:LoginService, private adminService:AdminService) { }

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      uname: ['', Validators.required],
      password: ['', Validators.required],
    })
  }

  signUp(){
    this.router.navigate(['/addUser']);
  }

  login(){
    if(this.lService.validateNewUser(this.loginForm.value)){
      this.lService.setLoginStatus(true);
      this.adminService.setAdminStatus(false);
      this.router.navigate(['/employee']);

    }
    else{
      this.message = "Invalid Login details check ID and Password";
      this.router.navigate(['/login']);
    }
  }
}


