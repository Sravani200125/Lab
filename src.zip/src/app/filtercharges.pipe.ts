import { Pipe, PipeTransform } from '@angular/core';
import { Doctor } from './doctorcrud/Doctor';


@Pipe({
  name: 'filtercharges'
})
export class FilterchargesPipe implements PipeTransform {

  transform(Doctors: Doctor[], searchFilter: string): Doctor[] {
    if (!Doctors || !searchFilter) {
      return Doctors;
    }
    else {
      return Doctors.filter(doctor => doctor.chargesPerVisit.toString().toLocaleLowerCase().includes(searchFilter.toLocaleLowerCase()));
    }
  }

}
