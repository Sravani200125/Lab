import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  userData:any=[];

  private urlUser =  "http://localhost:8085/mydoctorapp-user";
  private isLoginStatus:boolean=false;

  httpOptions = {
    headers:new HttpHeaders({
      'Content-Type':'application/json'
    })
  }

  constructor(private httpClient:HttpClient) { 
    this.getUserData().subscribe((data:any[])=>{
      this.userData = data;
    });

    console.log(this.userData);
    
  }

  getUserData():Observable<any>{
    return this.httpClient.get<any[]>(this.urlUser+"/user/all").
    pipe(
      catchError(this.handleError)
    )
  }

  getLoginStatus():any {
  return this.isLoginStatus;
  }

  setLoginStatus(status:boolean){
    this.isLoginStatus = status;
  }

  addUser(user: any):Observable<any[]>{
    return this.httpClient.post<any[]>(this.urlUser+"/user/adduser",JSON.stringify(user),this.httpOptions).
    pipe(
      catchError(this.handleError)
    )

  }

  validateNewUser(data:any):boolean{
    for(let s of this.userData){
      if(s.email===data.uname && s.password===data.password){
        return true;
      }
    }
    return false;
  }

  handleError(eResponse:HttpErrorResponse){
    if(eResponse.error instanceof ErrorEvent){
      console.log("Client side error = "+eResponse.error.message);
      console.log("Status Code="+eResponse.status)
    }
    else{
      console.log("Server side error = "+eResponse.error.message);
      console.log("Status Code="+eResponse.status)
    }
    return throwError(eResponse.error.message);
  }
}
