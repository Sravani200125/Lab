import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-approve',
  templateUrl: './admin-approve.component.html',
  styleUrls: ['./admin-approve.component.css']
})
export class AdminApproveComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  onClick(){
    this.router.navigate(['/employee/all'])
  }

  onClick1(){
    this.router.navigate(['/patient/allPatient'])
  }
  onClick2(){
    this.router.navigate(['/employee/addAppointment']);
  }

  onClick3(){
    this.router.navigate(['/patient/addPatient'])
  }

  onClick4(){
    this.router.navigate(['doctor/addDoctor']);
  }

  onClick5(){
    this.router.navigate(['doctor/allDoctor']);
  }

  onClick6(){
    this.router.navigate(['/viewfeed']);
  }

}
