import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  message:string;
  adminForm:FormGroup;

  constructor(private fb:FormBuilder , private router:Router, private adminService:AdminService){

  }

  ngOnInit(): void {
    this.adminForm = this.fb.group({
      uname: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    })
  }

  login(){
    if(this.adminService.validateLogin(this.adminForm.value)){
      this.adminService.setAdminStatus(true);
      this.router.navigate(['/admin/adminApprove']);
    }
    else{
      this.message = "Invalid Login details check ID and Password";
      this.router.navigate(['/admin']);
    }
  }

}
