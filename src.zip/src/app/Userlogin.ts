export class UserLogin{
    public userId:number;
    public userName:string;
    public password:string;
    public role:string;
}