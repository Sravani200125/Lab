import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminService } from 'src/app/admin.service';
import { AdminComponent } from 'src/app/admin/admin.component';
import { DocloginService } from 'src/app/doclogin.service';
import { EmpService } from '../emp.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  appointmentId:number;
  doctor:any;
  patient:any;
  appointmentDate:string;
  appointmentStatus:string;
  isAdminCheck:boolean;
  isDoctorCheck:boolean;

  emp:any;

  constructor(private  actRouter:ActivatedRoute, private eService:EmpService, private router:Router, private adminService : AdminService , private dService:DocloginService) {
    this.emp = new Employee();
    this.appointmentId = this.actRouter.snapshot.params['appointmentId'];
    console.log(this.actRouter)
    this.eService.getEmployeeById(this.appointmentId).subscribe(data=>{
      this.emp=data;
    })

   }
  ngOnInit(): void {
  }

  isCheck():boolean{
    this.isAdminCheck = this.adminService.getAdminStatus();
    this.isDoctorCheck = this.dService.getDoctorStatus();
    if(this.isAdminCheck==true || this.isDoctorCheck==true){
      return false;
    }
    else{
      return true;
    }
  }
  updateData(){
    console.log("updating data" ,this.emp);
    this.eService.UpdateEmployee(this.emp).subscribe(res=>{
      this.router.navigate(['/employee/all']);
    })
  }

}
