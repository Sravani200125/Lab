import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EmpService } from '../emp.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  empForm: FormGroup;
  errormessage:string;

  constructor(private fb: FormBuilder, private eService: EmpService,
    private router: Router) { }

  ngOnInit(): void {
    this.empForm = this.fb.group({
      appointmentId: ['', Validators.required],
      appointmentDate: ['', Validators.required],
      appointmentStatus: null,
      doctor:new FormGroup({
        doctorId: new FormControl('',Validators.required)
      }),
      patient: new FormGroup({
        patientId:new FormControl('', Validators.required)
      })
    })
  }

  regEmployee() {
    console.log(this.empForm.value);
    this.eService.addEmployee(this.empForm.value).subscribe(res =>{
      this.router.navigate(['/employee/all'])
    })
  }
}
