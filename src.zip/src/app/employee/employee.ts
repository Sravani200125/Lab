export class Employee {
    public appointmentId:number;
    public doctor:{
        doctorId:number
    };
    public patient:{
        patientId:number
    };
    public appointmentDate:string;
    public appointmentStatus:string;

}