import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  ngOnInit(): void {

  }

  constructor(private router:Router){}

  onClickTo(){
    this.router.navigate(['/addAppointment'])
  }
}
