import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, pipe, throwError } from 'rxjs';
import {catchError} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EmpService {

  private url="http://localhost:8085/mydoctorapp-appointment";

  httpOptions = {
    headers:new HttpHeaders({
      'Content-Type':'application/json'
    })
  }

  constructor(private httpClient:HttpClient) { }

  getEmployeeById(id:any):Observable<any>{
    return this.httpClient.get<any>(this.url+"/getappointmentbyid/"+id).
    pipe(
      catchError(this.handleError)
    )
  }

  addEmployee(emp: any):Observable<any[]>{
    return this.httpClient.post<any[]>(this.url+"/createappointment",JSON.stringify(emp),this.httpOptions).
    pipe(
      catchError(this.handleError)
    )

  }

  UpdateEmployee(emp: any):Observable<any>{
    return this.httpClient.put<any>(this.url+"/updateappointment",JSON.stringify(emp),this.httpOptions).
    pipe(
      catchError(this.handleError)
    )
  }

  getAllEmployee():Observable<any[]>{
    return this.httpClient.get<any[]>(this.url+"/appointment/all").
    pipe(
      catchError(this.handleError)
    )
  }
  

  deleteEmployee(appointmentId:number):Observable<any[]>{
    return this.httpClient.delete<any[]>(this.url+"/deleteappointment/"+appointmentId).
    pipe(
      catchError(this.handleError)
    )
  }

  handleError(eResponse:HttpErrorResponse){
    if(eResponse.error instanceof ErrorEvent){
      console.log("Client side error = "+eResponse.error.message);
      console.log("Status Code="+eResponse.status)
    }
    else{
      console.log("Server side error = "+eResponse.error.message);
      console.log("Status Code="+eResponse.status)
    }
    return throwError(eResponse.error.message);
  }
}
