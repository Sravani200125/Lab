import { Component, OnInit } from '@angular/core';
import { EmpService } from '../emp.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-all-employee',
  templateUrl: './all-employee.component.html',
  styleUrls: ['./all-employee.component.css']
})
export class AllEmployeeComponent implements OnInit {
  emps: any[];

  employees:Employee[]=[];
  employeeFilterValue!:string;

  employeeFilterByPatient!:string;
  employeeFilterByDoctor!:string;
  employeeFilterByID!:string;
  employeeFilterByDate!:string;
  employeeFilterByStatus!:string;

  constructor(private eService: EmpService) { }

  ngOnInit(): void {
    this.eService.getAllEmployee().subscribe((data)=>{
      this.emps=data;
    });
  }

  removeEmployee(appointmentId:number){
    this.eService.deleteEmployee(appointmentId).subscribe((data:Employee[])=>{
      this.emps=data;
    })
  }

}
