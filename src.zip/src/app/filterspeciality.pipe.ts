import { Pipe, PipeTransform } from '@angular/core';
import { Doctor } from './doctorcrud/Doctor';


@Pipe({
  name: 'speciality'
})
export class SpecialityPipe implements PipeTransform {

  transform(Doctors: Doctor[], searchFilter: string): Doctor[] {
    if (!Doctors || !searchFilter) {
      return Doctors;
    }
    else {
      return Doctors.filter(doctor => doctor.speciality.toString().toLocaleLowerCase().includes(searchFilter.toLocaleLowerCase()));
    }
  }

}
