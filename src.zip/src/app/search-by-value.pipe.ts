import { Pipe, PipeTransform } from '@angular/core';
import { Employee } from './employee/employee';

@Pipe({
  name: 'searchByValue'
})
export class SearchByValuePipe implements PipeTransform {

  transform(employees: Employee[], searchFilter: string): Employee[] {
    if (!employees || !searchFilter) {
      return employees;
    }
    else {
        return employees.filter(emp => 
          emp.patient.patientId.toString().toLocaleLowerCase().includes(searchFilter.toLocaleLowerCase()) ||
          emp.doctor.doctorId.toString().toLocaleLowerCase().includes(searchFilter.toLocaleLowerCase()) ||
          emp.appointmentStatus.toLocaleLowerCase().includes(searchFilter.toLocaleLowerCase()) ||
          emp.appointmentId.toString().toLocaleLowerCase().includes(searchFilter.toLocaleLowerCase()) ||
          emp.appointmentDate.toLocaleLowerCase().includes(searchFilter.toLocaleLowerCase()));
    }
  }

}
