import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminApproveComponent } from './admin/admin-approve/admin-approve.component'
import { AdminComponent } from './admin/admin.component';
import { AuthGuard } from './auth.guard';
import { AlldoctorComponent } from './doctorcrud/alldoctor/alldoctor.component';
import { CreatedoctorComponent } from './doctorcrud/createdoctor/createdoctor.component';
import { DoctorcrudComponent } from './doctorcrud/doctorcrud.component';
import { UpdatedoctorComponent } from './doctorcrud/updatedoctor/updatedoctor.component';
import { AllEmployeeComponent } from './employee/all-employee/all-employee.component';
import { CreateComponent } from './employee/create/create.component';
import { EmployeeComponent } from './employee/employee.component';
import { UpdateComponent } from './employee/update/update.component';
import { GivefeedbackComponent } from './givefeedback/givefeedback.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { CreatePatientComponent } from './patient/create-patient/create-patient.component';
import { FindallComponent } from './patient/findall/findall.component';
import { Patient } from './patient/patient';
import { PatientComponent } from './patient/patient.component';
import { UpdatePatientComponent } from './patient/update-patient/update-patient.component';
import { User } from './user';
import { UserComponent } from './user/user.component';
import { ViewfeedbackComponent } from './viewfeedback/viewfeedback.component';


const routes: Routes = [
  { path: '', redirectTo:'home', pathMatch:'full'},
  { path: 'login', component: LoginComponent},
  { path: 'addUser' , component: UserComponent},
  { path: 'home' , component: HomeComponent},
  { path: 'admin' , component: AdminComponent },
  { path: 'admin/adminApprove', component: AdminApproveComponent,canActivate:[AuthGuard]},
  { path: 'employee', component: EmployeeComponent},
  { path: 'employee/addAppointment' , component:CreateComponent,canActivate:[AuthGuard]},
  { path: 'employee/all', component: AllEmployeeComponent,canActivate:[AuthGuard] },
  { path: 'employee/update/:appointmentId', component: UpdateComponent,canActivate:[AuthGuard] },
  { path: 'patient' , component: PatientComponent},
  { path: 'patient/addPatient', component:CreatePatientComponent},
  { path: 'patient/allPatient', component:FindallComponent},
  { path: 'patient/updatePatient/:patientId', component:UpdatePatientComponent },
  { path: 'doctor' , component:DoctorcrudComponent },
  { path: 'doctor/addDoctor', component:CreatedoctorComponent },
  { path: 'doctor/allDoctor', component:AlldoctorComponent },
  { path: 'doctor/updateDoctor/:doctorId' , component:UpdatedoctorComponent },
  { path: 'givefeed', component:GivefeedbackComponent },
  { path: 'viewfeed', component:ViewfeedbackComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
