import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';

import { catchError } from 'rxjs/operators'
import { Doctor } from './doctorcrud/Doctor';


@Injectable({
  providedIn: 'root'
})
export class DoctorService {
  doclist: Doctor[] = [];
  private url="http://localhost:8085//mydoctorapp-doctor";
  httpOptions={
    headers:new HttpHeaders({
         'Content-Type':'application/json'
    })
  }

  constructor(private httpClient:HttpClient) { }

  addDoctor(doc: any):Observable<Doctor[]> {
    return this.httpClient.post<Doctor[]>(this.url+'/createdoctor',JSON.stringify(doc),this.httpOptions)
    .pipe(
      catchError(this.handleError)
    )


  }

  getAllDoc():Observable<Doctor[]> {
    return this.httpClient.get<Doctor[]>(this.url+'/doctor/all')
    .pipe(
      catchError(this.handleError)
    )

  }

  getDoctorById(doctorId:number):Observable<Doctor> {
    return this.httpClient.get<Doctor>(this.url+'/getdoctorbyid/'+doctorId)
    .pipe(
      catchError(this.handleError)
    )

  }

  updateDoctor(doc:any):Observable<any>{
    return this.httpClient.put<Doctor>(this.url+'/updatedoctor',JSON.stringify(doc), this.httpOptions)
    .pipe(
      catchError(this.handleError)
    )


  }

  deleteDoctor(doctorId:number):Observable<any>{
    return this.httpClient.delete<Doctor[]>(this.url+'/deletedoctor/'+doctorId)
    .pipe(
      catchError(this.handleError)
    )

  }

  handleError(eResponse: HttpErrorResponse) {
    if (eResponse.error instanceof ErrorEvent) {
      console.log("Client Side Error =" + eResponse.error.message);
      console.log("Status Code=" + eResponse.status);
    }
    else {
      console.log("Server Side Error =" + eResponse.error.message);
      console.log("Status Code=" + eResponse.status);
    }
    return throwError(eResponse.error.message);
  }

}
