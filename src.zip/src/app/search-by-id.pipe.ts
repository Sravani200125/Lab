import { Pipe, PipeTransform } from '@angular/core';
import { Employee } from './employee/employee';

@Pipe({
  name: 'searchById'
})
export class SearchByIDPipe implements PipeTransform {

  transform(employees: Employee[], searchFilter: string): Employee[] {
    if (!employees || !searchFilter) {
      return employees;
    }
    else {
        return employees.filter(emp => emp.appointmentId.toString().toLocaleLowerCase().includes(searchFilter.toLocaleLowerCase()));
    }
  }

}