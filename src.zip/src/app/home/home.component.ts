import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { DocloginService } from '../doclogin.service';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private router:Router, private lService:LoginService, private dService:DocloginService, private adminService:AdminService) { }

  ngOnInit(): void {
  }

  addAppointmentNavigate(){
    this.router.navigate(['/add']);
  }

  logOut(){
    this.lService.setLoginStatus(false);
    this.dService.setDoctorStatus(false);
    this.adminService.setAdminStatus(false);
  }

}
