import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Patient } from './patient/patient';

@Injectable({
  providedIn: 'root'
})
export class PatientService {
  doclist: Patient[] = [];
  private url="http://localhost:8085//mydoctorapp-patient";
  httpOptions={
    headers:new HttpHeaders({
         'Content-Type':'application/json'
    })
  }
  

  constructor(private httpClient:HttpClient) { }

  getAllPat():Observable<Patient[]> {
    return this.httpClient.get<Patient[]>(this.url+'/patient/all')
  }
}
