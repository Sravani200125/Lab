import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  login:any=[];

  private urlAdmin = "http://localhost:8085/mydoctorapp-admin/admin/all";
  private isAdminStatus:boolean=false;
  
  httpOptions = {
    headers:new HttpHeaders({
      'Content-Type':'application/json'
    })
  }
  
  constructor(private httpClient:HttpClient){
    this.getAdminData().subscribe((data:any[])=>{
      this.login = data;
    });
  } 

  getAdminStatus():any {
    return this.isAdminStatus;
  }
  
  setAdminStatus(status:boolean){
      this.isAdminStatus = status;
  }

  getAdminData():Observable<any>{
    return this.httpClient.get<any[]>(this.urlAdmin).
    pipe(
      catchError(this.handleError)
    )
  }

  validateLogin(data:any):boolean{
    for(let e of this.login){
      if(e.email===data.uname && e.password===data.password){
        return true;
      }
    }
    return false;
  }

  handleError(eResponse:HttpErrorResponse){
    if(eResponse.error instanceof ErrorEvent){
      console.log("Client side error = "+eResponse.error.message);
      console.log("Status Code="+eResponse.status)
    }
    else{
      console.log("Server side error = "+eResponse.error.message);
      console.log("Status Code="+eResponse.status)
    }
    return throwError(eResponse.error.message);
  }
}
