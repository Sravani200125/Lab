import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { DocloginService } from '../doclogin.service';

@Component({
  selector: 'app-doctorcrud',
  templateUrl: './doctorcrud.component.html',
  styleUrls: ['./doctorcrud.component.css']
})
export class DoctorcrudComponent implements OnInit {

  loginDocForm:FormGroup;
  message:string;

  constructor(private fb:FormBuilder ,private dService:DocloginService, private adminService:AdminService, private router:Router) { }

  ngOnInit(): void {
    this.loginDocForm = this.fb.group({
      uname: ['', [Validators.required,Validators.email]],
      password: ['', Validators.required]
    })
  }

  login(){
    if(this.dService.validate(this.loginDocForm.value)){
      console.log(this.dService.userList)
      this.dService.setDoctorStatus(true);
      this.adminService.setAdminStatus(false);
      this.router.navigate(['/employee/all']);

    }
    else{
      console.log(this.dService.userList)
      this.message = "Invalid Login details check ID and Password";
      this.router.navigate(['/doctor']);
    }
  }

  onClick(){
    this.router.navigate(['/addUser']);
  }

}
