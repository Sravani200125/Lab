import { Component, OnInit } from '@angular/core';
import { DoctorService } from 'src/app/doctor.service';
import { Doctor } from '../Doctor';


@Component({
  selector: 'app-alldoctor',
  templateUrl: './alldoctor.component.html',
  styleUrls: ['./alldoctor.component.css']
})
export class AlldoctorComponent implements OnInit {
  docs: any[];

  filterById:string;
  filterByName:string;
  filterBySpeciality:string;
  filterByLocation:string;
  filterByHospitalName:string;
  filterByMobileNo:string;
  filterByCharges:string;

  constructor(private dService:DoctorService) { }

  ngOnInit(): void {
    this.dService.getAllDoc().subscribe((data:Doctor[])=>{
      this.docs=data;
    })
  }

  removeDoc(doctorId:number){
    this.dService.deleteDoctor(doctorId).subscribe((data:Doctor[])=>{
      this.docs=data;
    })
  }

}
