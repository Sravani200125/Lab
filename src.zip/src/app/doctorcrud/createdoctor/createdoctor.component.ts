import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DoctorService } from 'src/app/doctor.service';

@Component({
  selector: 'app-createdoctor',
  templateUrl: './createdoctor.component.html',
  styleUrls: ['./createdoctor.component.css']
})
export class CreatedoctorComponent implements OnInit {
  docForm: FormGroup;
  errorMessage: string;


  constructor(private fb: FormBuilder, private router: Router,private dService:DoctorService) { }

  ngOnInit(): void {
    this.docForm = this.fb.group({
      doctorId: ['', Validators.required],
      doctorName: ['', [Validators.required, Validators.pattern("^[a-zA-Z\\s]*$")]],
      speciality: ['', [Validators.required, Validators.pattern("^[a-zA-Z\\s]*$")]],
      location:['',Validators.required],
      hospitalName: ['', [Validators.required,Validators.pattern("^[a-zA-Z\\s]*$")]],
      mobileNo: ['', [Validators.required,Validators.pattern("[6-9][0-9 ]{9}")]],
      chargesPerVisit: ['', [Validators.required, Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")]]

    })
  }


  get charge(){
    return this.docForm.get('chargesPerVisit');
  }

  get hname(){
    return this.docForm.get('hospitalName');
  }

  get name() {
    return this.docForm.get('doctorName');
  }

  get location() {
    return this.docForm.get('location');
  }

  get spec() {
    return this.docForm.get('speciality');
  }

  get phNumber(){
    return this.docForm.get('mobileNo');
  }

  regDoctor() {
    this.dService.addDoctor(this.docForm.value).subscribe(res => {
      this.router.navigate(['/doctor/allDoctor']);
    }, error => {
      this.errorMessage = error;
    }
    )


  }

}
