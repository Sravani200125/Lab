export class Doctor{
    public doctorId:number;
    public doctorName:string;
    public speciality:string;
    public location:string;
    public hospitalName:string;
    public mobileNo:number;
    public chargesPerVisit:number;
    
}