import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DoctorService } from 'src/app/doctor.service';
import { Doctor } from '../Doctor';


@Component({
  selector: 'app-updatedoctor',
  templateUrl: './updatedoctor.component.html',
  styleUrls: ['./updatedoctor.component.css']
})
export class UpdatedoctorComponent implements OnInit {
  doctorId:number;
  doc:Doctor;

  constructor(private actRouter:ActivatedRoute ,private dService:DoctorService,private router:Router) { }

  ngOnInit(): void {
    this.doc=new Doctor();
    this.doctorId=this.actRouter.snapshot.params['doctorId'];
    this.dService.getDoctorById(this.doctorId).subscribe(data=>{
      this.doc=data;

    })
  }

  updateData(){
    this.dService.updateDoctor(this.doc).subscribe(res=>{
      this.router.navigate(['/doctor/allDoctor']);
    })
  }


}
