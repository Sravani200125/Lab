export class Feedback{
    public patient:any;
    public doctor:any;
    public rating:number;
    public feedback:string;
}